SARU BIRTHDAY WEBSITE

1. Open index.html in a browser to preview the website.
2. The six photos are already included in the same folder.
3. To put it online, upload the whole folder to a static hosting service such as GitHub Pages, Netlify, or another HTML hosting service.
4. Send your friend the resulting website link.

Everything is self-contained except the hosting service. No external images are used.
